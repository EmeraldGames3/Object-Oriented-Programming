#pragma once

#include "Time.h"
#include <cassert>

void testDay();