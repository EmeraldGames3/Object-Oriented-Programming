#include "TestAll.h"

void testAll(){
    testTime();
    testDomain();
    testRepository();
    testController();
}