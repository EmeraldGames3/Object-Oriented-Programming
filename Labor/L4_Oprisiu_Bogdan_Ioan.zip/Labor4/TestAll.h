#pragma once
#include "TestDomain.h"
#include "TestTime.h"
#include "TestRepository.h"
#include "TestController.h"

void testAll();