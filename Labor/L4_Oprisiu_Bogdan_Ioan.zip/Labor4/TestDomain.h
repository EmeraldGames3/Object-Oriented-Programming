#pragma once
#include <cassert>
#include "Domain.h"

using namespace Domain;

void testDomain();