#pragma once

#include "TestDay.h"
#include "TestDate.h"
#include "TestExactDate.h"
#include <cassert>

void testTime();