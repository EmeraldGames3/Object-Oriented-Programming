#pragma once

#include "FruitController.h"

namespace Controller{
    class FruitController;
}