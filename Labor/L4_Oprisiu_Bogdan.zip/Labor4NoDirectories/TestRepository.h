#pragma once

#include "Repository.h"
#include "Domain.h"

void testRepository();