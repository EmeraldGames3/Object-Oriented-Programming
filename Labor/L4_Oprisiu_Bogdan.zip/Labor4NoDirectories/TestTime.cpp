#include "TestTime.h"

void testTime(){
    testDay();
    testDate();
    testExactDate();
}