#include "TestAll.h"
#include "UI.h"

using namespace UI;

int main() {
    testAll();

    UserInterface userInterface;
    userInterface.run();
}