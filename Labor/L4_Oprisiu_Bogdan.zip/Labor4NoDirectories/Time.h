#pragma once

#include "Date.h"
#include "Day.h"
#include "ExactDate.h"

namespace Time {
    class Date;
    class Day;
    class ExactDate;
}