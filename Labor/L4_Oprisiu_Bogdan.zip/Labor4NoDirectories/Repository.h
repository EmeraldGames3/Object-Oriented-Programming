#pragma once

#include "FruitRepository.h"

namespace Repository{
    class FruitRepository;
}