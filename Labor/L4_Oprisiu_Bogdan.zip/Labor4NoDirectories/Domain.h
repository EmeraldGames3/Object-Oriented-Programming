#pragma once

#include "Fruit.h"

namespace Domain{
    class Fruit;
}