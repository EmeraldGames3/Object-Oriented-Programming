#pragma once

#include "UserInterface.h"

namespace UI{
    class UserInterface;
}